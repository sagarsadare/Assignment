import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filesearch'
})
export class FilesearchPipe implements PipeTransform {

  transform(value: any, args?: any): any {

    if (!args) {
      return value;
    }
    return value.filter(val => {
      let rVal =
        val.ID.toString()
          .toLocaleLowerCase()
          .includes(args) || val.File.toLocaleLowerCase().includes(args);
      return rVal;
    });
  }
}
