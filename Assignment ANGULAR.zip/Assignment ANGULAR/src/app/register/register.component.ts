import { Component, OnInit } from '@angular/core';
// import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { FileService } from "../services/file.service";
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  loading = false;
  submitted = false;
  ipAddress;
  constructor(
    private formBuilder: FormBuilder, private router: Router, private fileService: FileService) {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit() {
    this.getIpAdress();
  }

  onSubmit(values) {
    this.submitted = true;

    this.fileService.register(this.registerForm.value, this.ipAddress)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['/login']);
        },
        error => {
          this.loading = false;
        });
  }
  getIpAdress() {
    this.fileService.getIPAddress().subscribe((res: any) => {
      this.ipAddress = res.ip;
    })
  }

}
