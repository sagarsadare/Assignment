import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ItemsComponent } from './items/items.component';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
// import { routingModule } from './app.routing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DndDirective } from './items/dnd.directive';
// import { HeaderComponent } from './header/header.component';
import { RegisterComponent } from './register/register.component';
import { DashboardAuthGuard } from './auth/dashboard.auth.guard';
import { LoginAuthGuard } from './auth/login.auth.guard';
import { FilesearchPipe } from './items/filesearch.pipe';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    ItemsComponent,
    DndDirective,
    // HeaderComponent,
    RegisterComponent,
    FilesearchPipe
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    // routingModule
  ],
  providers: [DashboardAuthGuard,LoginAuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
