import { Component, OnInit } from '@angular/core';
import { FileService } from "../services/file.service";
import { Router } from '@angular/router';
@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  files = [];
  filesForTable = []
  Filename;
  constructor(
    private uploadService: FileService,
    private router: Router
  ) { }
  oninit = false;
  ngOnInit() {
    this.oninit = true;
    this.getAllFiles();
  }

  onFileDropped($event) {
    this.oninit = false;
    this.files = [];
    this.prepareFilesList($event);
  }


  prepareFilesList(files: Array<any>) {
    // console.log('inside prepare list--->>>', files);
    for (const item of files) {
      item.progress = 0;
      this.files.push(item);
    }
    this.uploadFilesSimulator(0);
  }

  uploadFilesSimulator(index: number) {
    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

  deleteFile(index: number) {

    this.files.splice(index, 1);
  }


  formatBytes(bytes, decimals) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  uploadFile(files) {
    this.filesForTable = [];
    // console.log('inside upload file------>>>', files);
    // let validationData=this.getlocalStorageData();
    const formData = new FormData();
    let token = localStorage.getItem('Token');
    let email = localStorage.getItem('Email');
    formData.append('Token', token);
    formData.append('Email', email);
    for (let i = 0; i < files.length; i++) {
      formData.append(files[i].name, files[i])
    }


    // console.log('file inside upload file formdata---->>>', formData);
    this.uploadService.upload(formData).subscribe((res: any) => {
      // console.log('res upload file------------>>>', res);

      if (res.status == 200) {
        this.files = [];
        this.filesForTable = [];
        this.getAllFiles();
      }
    });
  }
  dataExist = false;

  tokenToValidate;
  emailTovaildate
  getlocalStorageData() {
    let token = localStorage.getItem('Token');
    let email = localStorage.getItem('Email');
    let validationData = {
      Token: token,
      Email: email
    }
    return validationData;
  }

  getAllFiles() {
    this.dataExist = false;
    this.files = [];
    this.filesForTable = []
    this.uploadService.getFiles().subscribe((res) => {
      if (res.responseResult.length > 0) {
        this.files = [];
        this.filesForTable = []
        res.responseResult.forEach(element => {
          let obj = { ID: "", File: "" }
          let tempfname = element.FILE.split("-");
          let fname = tempfname[tempfname.length - 1]
          obj.ID = element.ID;
          obj.File = fname;
          this.filesForTable.push(obj)
        });
      }
      else {
        // console.log('no data found');
      }

      if (this.filesForTable.length > 0) {
        this.dataExist = true
      }
      // console.log('this.files--->>>', this.files);
    })

  }

  onClick() {
    // console.log('inside on click file array to send --->>>', this.files);
    this.uploadFile(this.files);
  }

  deleteEquip(object) {
    // console.log('delete object------------->>>', object);
    let token = localStorage.getItem('Token');
    let email = localStorage.getItem('Email');

    if (confirm('Are you sure want to Delete?')) {
      let data = {
        Token: token,
        Email: email,
        ID: object.ID,
        File: object.File

      }
      // console.log('inside delete File ', data);
      this.uploadService.deleteFiles(data).subscribe((res) => {
        // console.log('res--->>', res);
        if (res) {
          this.files = [];
          this.filesForTable = [];
          this.getAllFiles();
        }
      })

    }
  }

  setUpdateModal(value) { }

  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  logout() {
    // console.log('inside logout--->>>');
    if (confirm('Are you sure want to logout?')) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

}
