import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FileService } from "../services/file.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  loginForm: FormGroup;
  processing: Boolean = false;
  error: Boolean = false;
  ipAddress;

  constructor(private router: Router, private _fileService: FileService, private fb: FormBuilder) {

    this.loginForm = fb.group({
      username: [null, [Validators.required, Validators.email]],
      password: [null, Validators.required],
    });

  }

  ngOnInit() {
    this.getIpAdress()
  }
  onSubmitButtonClicked(values) {
    this.error = false;
    this.processing = false;
    if (this.loginForm.valid) {
      this.login(values);
    }
  }

  private login(values) {
    this.processing = true;
    let data = {
      ipAddress: this.ipAddress,
      logindata: values,

    }
    this._fileService.myLogin(data).subscribe(res => {
      if (res.code == 200) {
        this.handleLoginSuccess(res);
      } else {
        this.handleLoginError();
      }
    });
  }

  private handleLoginSuccess(res) {
    this.processing = false;
    this.error = false;
    localStorage.setItem('Token', res.Token);
    localStorage.setItem('Email', res.email);
    this.router.navigate(['/items']);
  }
  invalidCredentials = false
  private handleLoginError() {
    this.invalidCredentials = true;
    alert('email or password is incorrect')
  }

  get registerFormControl() {
    return this.loginForm.controls;
  }

  getIpAdress() {
    this._fileService.getIPAddress().subscribe((res: any) => {
      this.ipAddress = res.ip;
    })
  }



}
